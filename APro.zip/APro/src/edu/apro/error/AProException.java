/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.error;

/**
 *
 * @author Tsukandar
 */
public class AProException extends Exception {

    /**
     * Creates a new instance of <code>AProException</code> without detail
     * message.
     */
    public AProException() {
    }

    /**
     * Constructs an instance of <code>AProException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public AProException(String msg) {
        super(msg);
    }
}
