/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.main;

import edu.apro.database.AProDatabase;
import edu.apro.entity.AProAbsensi;
import edu.apro.entity.AProPegawai;
import edu.apro.entity.AProProyek;
import edu.apro.error.AProException;
import edu.apro.service.AProDaoAbsensi;
import edu.apro.service.AProDaoPegawai;
import edu.apro.service.AProDaoProyek;
import edu.apro.view.AProMainView;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;

/**
 *
 * @author Tsukandar
 */
public class AProMain {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws SQLException, AProException {
        // TODO code application logic here

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                AProMainView view = new AProMainView();
                view.setVisible(true);

            }
        });

    }
}
