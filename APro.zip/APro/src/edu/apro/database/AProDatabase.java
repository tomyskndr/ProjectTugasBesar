/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.database;

import com.mysql.jdbc.jdbc2.optional.MysqlDataSource;
import edu.apro.impl.AProDaoAbsensiImpl;
import edu.apro.impl.AProDaoPegawaiImpl;
import edu.apro.impl.AProDaoProyekImpl;
import java.sql.Connection;
import java.sql.SQLException;
import edu.apro.service.AProDaoAbsensi;
import edu.apro.service.AProDaoPegawai;
import edu.apro.service.AProDaoProyek;



/**
 *
 * @author Tsukandar
 */
public class AProDatabase {
    private static Connection connection;
    private static AProDaoAbsensi aproDaoAbsensi;
    private static AProDaoPegawai aproDaoPegawai;
    private static AProDaoProyek aproDaoProyek;
    
    public static Connection getConnection()throws SQLException{
        if (connection==null) {
            
            MysqlDataSource dataSource = new MysqlDataSource();
            dataSource.setURL("jdbc:mysql://localhost:3306/proyekdatabase");
            dataSource.setUser("root");
            dataSource.setPassword("");
            connection = dataSource.getConnection(); 
        }
        
        
        return connection;
    }
    public static AProDaoAbsensi getAProDaoAbsensi() throws SQLException{
        
        if(aproDaoAbsensi==null){
            aproDaoAbsensi = new AProDaoAbsensiImpl(getConnection());
        }
        return aproDaoAbsensi;
    }
    public static AProDaoPegawai getAProDaoPegawai() throws SQLException{
        
        if(aproDaoPegawai==null){
            aproDaoPegawai = new AProDaoPegawaiImpl(getConnection());
        }
        return aproDaoPegawai;
    }
    public static AProDaoProyek getAProDaoProyek() throws SQLException{
        
        if(aproDaoProyek==null){
            aproDaoProyek = new AProDaoProyekImpl(getConnection());
        }
        return aproDaoProyek;
    }
    
}
