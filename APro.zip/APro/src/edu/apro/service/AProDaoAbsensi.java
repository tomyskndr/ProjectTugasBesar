/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.service;

import edu.apro.entity.AProAbsensi;
import edu.apro.error.AProException;
import java.util.List;

/**
 *
 * @author Tsukandar
 */
public interface AProDaoAbsensi {

    public void insertAbsensi(AProAbsensi aproAbsensi) throws AProException;

    public void updateAbsensi(AProAbsensi aproAbsensi) throws AProException;

    public void deleteAbsensi(String noAbsen) throws AProException;

    public AProAbsensi getAProAbsensi(String namaPegawai) throws AProException;

    public List<AProAbsensi> selectAllAProAbsensi() throws AProException;

}
