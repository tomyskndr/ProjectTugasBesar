/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.service;

import edu.apro.entity.AProAbsensi;
import edu.apro.entity.AProPegawai;
import edu.apro.entity.AProProyek;
import edu.apro.error.AProException;
import java.util.List;

/**
 *
 * @author Tsukandar
 */
public interface AProDaoProyek {
    public void insertProyek(AProProyek aproProyek) throws AProException;

    public void updateProyek(AProProyek aproProyek) throws AProException;

    public void deleteProyek(String kodeProyek) throws AProException;

    public AProProyek getAProProyek(String namaProyek) throws AProException;

    public List<AProProyek> selectAllAProProyek() throws AProException;
}
