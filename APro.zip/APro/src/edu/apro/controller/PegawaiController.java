/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.controller;

import edu.apro.entity.AProPegawai;
import edu.apro.model.PegawaiModel;
import edu.apro.view.AProMainView;
import edu.apro.view.TambahPegawaiView;
import javax.swing.JOptionPane;

/**
 *
 * @author Tsukandar
 */
public class PegawaiController {

    private PegawaiModel pegawaiModel;
    
    public void setModel(PegawaiModel pegawaiModel) {
        this.pegawaiModel = pegawaiModel;
    }

    public void insertPegawai(TambahPegawaiView tambah) {

        String namaPegawai = tambah.getTxtNamaPegawai().getText();
        String idPegawai = tambah.getTxtId().getText();
        String bagian = tambah.getTxtBagian().getText();
       
        String noTelp = tambah.getTxtNoTelp().getText();

        if (namaPegawai.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Nama tidak boleh kosong");
        } else if (idPegawai.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Id Pegawai tidak boleh kosong");
        } else if (bagian.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Nama Bagian tidak boleh kosong");
        }  else if (noTelp.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "No Telepon tidak boleh kosong");
        } else {
            pegawaiModel.setNamaPegawai(namaPegawai);
            pegawaiModel.setIdPegawai(idPegawai);
            pegawaiModel.setBagian(bagian);
            pegawaiModel.setAlamatPegawai(namaPegawai);
            pegawaiModel.setNoTelp(noTelp);

            try {
                pegawaiModel.insertPegawai();
                JOptionPane.showMessageDialog(tambah, "Berhasil Ditambahkan");

            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(tambah, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }

    }

    public void updatePegawai(TambahPegawaiView tambah) {

        if (tambah.getTablePegawai().getSelectedRowCount() == 0) {
            JOptionPane.showMessageDialog(tambah, "Silahkan pilih baris data yang akan diubah");
            return;
        }

        String idPegawai = tambah.getTxtId().getText();
        String namaPegawai = tambah.getTxtNamaPegawai().getText();
        String bagian = tambah.getTxtBagian().getText();
        
        String noTelp = tambah.getTxtNoTelp().getText();

        if (namaPegawai.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Nama tidak boleh kosong");
        } else {
            pegawaiModel.setIdPegawai(idPegawai);
            pegawaiModel.setNamaPegawai(namaPegawai);
            pegawaiModel.setBagian(bagian);
           
            pegawaiModel.setNoTelp(noTelp);

            try {
                pegawaiModel.updatePegawai();
                JOptionPane.showMessageDialog(tambah, "Berhasil DiUbah");
                
            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(tambah, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }

    }

    public void deletePegawai(TambahPegawaiView tambah) {
        if (tambah.getTablePegawai().getSelectedRowCount() == 0) {
            JOptionPane.showMessageDialog(tambah, "Silahkan pilih baris data yang akan dihapus");
            return;
        }

        if (JOptionPane.showConfirmDialog(tambah, "Anda yakin akan menghapus?") == JOptionPane.OK_OPTION) {
            String idPegawai = tambah.getTxtId().getText();
            pegawaiModel.getIdPegawai();

            try {
                pegawaiModel.deletePegawai();
                JOptionPane.showMessageDialog(tambah, "Berhasil Dihapus");
                
            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(tambah, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }
    }

}
