/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.controller;

import edu.apro.model.AbsensiModel;
import edu.apro.view.AProMainView;
import edu.apro.view.AbsensiPegawaiView;
import javax.swing.JOptionPane;

/**
 *
 * @author Tsukandar
 */
public class AbsensiController {
    private AbsensiModel absensiModel;

    public void setModel(AbsensiModel absensiModel) {
        this.absensiModel = absensiModel;
    }

    public void insertAbsensi(AbsensiPegawaiView view) {

        String noAbsen = view.getTxtNoAbsen().getText();
        String idPegawai = view.getTxtId().getText();
        String bagian = view.getTxtBagian().getText();
        String upah = view.getTxtUpah().getText();
        String jumlahKehadiran = view.getTxtJh().getText();

        if (noAbsen.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "No Absen tidak boleh kosong");
        } else if (idPegawai.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "Id Pegawai tidak boleh kosong");
        } else if (bagian.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "Nama Bagian tidak boleh kosong");
        } else if (upah.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "Alamat tidak boleh kosong");
        } else if (jumlahKehadiran.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "No Telepon tidak boleh kosong");
        } else {
            absensiModel.setNoAbsen(noAbsen);
            absensiModel.setIdPegawai(idPegawai);
            absensiModel.setBagian(bagian);
            absensiModel.setUpah(upah);
            absensiModel.setJumlahKehadiran(jumlahKehadiran);

            try {
                absensiModel.insertAbsensi();
                JOptionPane.showMessageDialog(view, "Berhasil Ditambahkan");

            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(view, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }

    }

    public void updateAbsensi(AbsensiPegawaiView view) {

        if (view.getTableAbsensi().getSelectedRowCount() == 0) {
            JOptionPane.showMessageDialog(view, "Silahkan pilih baris data yang akan diubah");
            return;
        }

        String noAbsen = view.getTxtNoAbsen().getText();
        String idPegawai = view.getTxtId().getText();
        String bagian = view.getTxtBagian().getText();
        String upah = view.getTxtUpah().getText();
        String jumlahKehadiran = view.getTxtJh().getText();

        if (noAbsen.trim().equals("")) {
            JOptionPane.showMessageDialog(view, "No Absen tidak boleh kosong");
        } else {
            absensiModel.setNoAbsen(noAbsen);
            absensiModel.setIdPegawai(idPegawai);
            absensiModel.setBagian(bagian);
            absensiModel.setUpah(upah);
            absensiModel.setJumlahKehadiran(jumlahKehadiran);

            try {
                absensiModel.updateAbsensi();
                JOptionPane.showMessageDialog(view, "Berhasil DiUbah");
                
            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(view, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }

    }

    public void deleteAbsensi(AbsensiPegawaiView view) {
        if (view.getTableAbsensi().getSelectedRowCount() == 0) {
            JOptionPane.showMessageDialog(view, "Silahkan pilih baris data yang akan dihapus");
            return;
        }

        if (JOptionPane.showConfirmDialog(view, "Anda yakin akan menghapus?") == JOptionPane.OK_OPTION) {
            String idPegawai = view.getTxtId().getText();
            absensiModel.getIdPegawai();

            try {
                absensiModel.deleteAbsensi();
                JOptionPane.showMessageDialog(view, "Berhasil Dihapus");
                
            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(view, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }
    }
}
