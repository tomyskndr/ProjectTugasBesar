/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.controller;

import edu.apro.model.ProyekModel;
import edu.apro.view.AProMainView;
import edu.apro.view.TambahProyekView;
import javax.swing.JOptionPane;



/**
 *
 * @author Tsukandar
 */
public class ProyekController {

    private ProyekModel proyekModel;

    public void setModel(ProyekModel proyekModel) {
        this.proyekModel = proyekModel;
    }

    public void insertproyek(TambahProyekView tambah) {

        String kodeProyek = tambah.getTxtKodeProyek().getText();
        String namaProyek = tambah.getTxtNamaProyek().getText();
        

        if (kodeProyek.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Kode Proyek tidak boleh kosong");
        } else if (namaProyek.trim().equals("")) {
            JOptionPane.showMessageDialog(tambah, "Nama Proyektidak boleh kosong");
        } 
        else {
            proyekModel.setKodeProyek(kodeProyek);
            proyekModel.setNamaProyek(namaProyek);
            

            try {
                proyekModel.insertProyek();
                JOptionPane.showMessageDialog(tambah, "Berhasil Ditambahkan");

            } catch (Throwable throwable) {
                JOptionPane.showMessageDialog(tambah, new Object[]{"Terjadi error di database dengan pesan ", throwable.getMessage()});
            }
        }

    }

   

   
}