/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.model;

import edu.apro.database.AProDatabase;
import edu.apro.entity.AProPegawai;
import edu.apro.entity.AProProyek;
import edu.apro.error.AProException;
import edu.apro.event.ProyekListener;
import edu.apro.service.AProDaoPegawai;
import edu.apro.service.AProDaoProyek;
import java.sql.SQLException;

/**
 *
 * @author Tsukandar
 */
public class ProyekModel {
    
    private String kodeProyek;
    private String namaProyek;
    private String idPegawai;
    
    private ProyekListener proyekListener;

    public ProyekListener getProyekListener() {
        return proyekListener;
    }

    public void setProyekListener(ProyekListener proyekListener) {
        this.proyekListener = proyekListener;
    }
    

    public String getKodeProyek() {
        return kodeProyek;
    }

    public void setKodeProyek(String kodeProyek) {
        this.kodeProyek = kodeProyek;
    }

    public String getNamaProyek() {
        return namaProyek;
    }

    public void setNamaProyek(String namaProyek) {
        this.namaProyek = namaProyek;
    }

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    protected void fireOnChange() {
        if (proyekListener != null) {
            proyekListener.onChange(this);
        }
    }

    protected void fireOnInsert(AProProyek aproProyek) {
        if (proyekListener != null) {
            proyekListener.onInsert(aproProyek);
        }
    }

    protected void fireOnUpdate(AProProyek aproProyek) {
        if (proyekListener != null) {
            proyekListener.onUpdate(aproProyek);
        }
    }

    protected void fireOnDelete() {
        if (proyekListener != null) {
            proyekListener.onDelete();
        }
    }

    public void insertProyek() throws SQLException, AProException {

        AProDaoProyek aproDaoProyek = AProDatabase.getAProDaoProyek();
        AProProyek aproProyek = new AProProyek();
        aproProyek.setKodeProyek(kodeProyek);
        aproProyek.setNamaProyek(namaProyek);
        aproProyek.setIdPegawai(idPegawai);

        aproDaoProyek.insertProyek(aproProyek);
        fireOnInsert(aproProyek);
    }

    public void updateProyek() throws SQLException, AProException {

        AProDaoProyek aproDaoProyek = AProDatabase.getAProDaoProyek();
        AProProyek aproProyek = new AProProyek();
        aproProyek.setKodeProyek(kodeProyek);
        aproProyek.setNamaProyek(namaProyek);
        aproProyek.setIdPegawai(idPegawai);

        aproDaoProyek.updateProyek(aproProyek);
        fireOnUpdate(aproProyek);
    }

    public void deleteProyek() throws SQLException, AProException {

        AProDaoProyek aproDaoProyek = AProDatabase.getAProDaoProyek();
        aproDaoProyek.deleteProyek(kodeProyek);
        fireOnDelete();
    }

    
    
}
