/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.model;

import edu.apro.database.AProDatabase;
import edu.apro.entity.AProPegawai;
import edu.apro.error.AProException;
import edu.apro.event.PegawaiListener;
import edu.apro.service.AProDaoPegawai;
import java.sql.SQLException;
import kelompok11.tugasbesar.error.AbsensiException;

/**
 *
 * @author Tsukandar
 */
public class PegawaiModel {

    private String idPegawai;
    private String namaPegawai;
    private String bagian;
    private String alamatPegawai;
    private String noTelp;

    private PegawaiListener pegawaiListener;

    public PegawaiListener getPegawaiListener() {
        return pegawaiListener;
    }

    public void setPegawaiListener(PegawaiListener pegawaiListener) {
        this.pegawaiListener = pegawaiListener;
    }

    

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getNamaPegawai() {
        return namaPegawai;
    }

    public void setNamaPegawai(String namaPegawai) {
        this.namaPegawai = namaPegawai;
    }

    public String getBagian() {
        return bagian;
    }

    public void setBagian(String bagian) {
        this.bagian = bagian;
    }

    public String getAlamatPegawai() {
        return alamatPegawai;
    }

    public void setAlamatPegawai(String alamatPegawai) {
        this.alamatPegawai = alamatPegawai;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    

    protected void fireOnChange() {
        if (pegawaiListener != null) {
            pegawaiListener.onChange(this);
        }
    }

    protected void fireOnInsert(AProPegawai aproPegawai) {
        if (pegawaiListener != null) {
            pegawaiListener.onInsert(aproPegawai);
        }
    }

    protected void fireOnUpdate(AProPegawai aproPegawai) {
        if (pegawaiListener != null) {
            pegawaiListener.onUpdate(aproPegawai);
        }
    }

    protected void fireOnDelete() {
        if (pegawaiListener != null) {
            pegawaiListener.onDelete();
        }
    }

    public void insertPegawai() throws SQLException, AProException {

        AProDaoPegawai aproDaoPegawai = AProDatabase.getAProDaoPegawai();
        AProPegawai aproPegawai = new AProPegawai();
        aproPegawai.setIdPegawai(idPegawai);
        aproPegawai.setNamaPegawai(namaPegawai);
        aproPegawai.setBagian(bagian);
        aproPegawai.setAlamatPegawai(alamatPegawai);
        aproPegawai.setNoTelp(noTelp);

        aproDaoPegawai.insertPegawai(aproPegawai);
        fireOnInsert(aproPegawai);
    }

    public void updatePegawai() throws SQLException, AProException {

        AProDaoPegawai aproDaoPegawai = AProDatabase.getAProDaoPegawai();
        AProPegawai aproPegawai = new AProPegawai();
        aproPegawai.setIdPegawai(idPegawai);
        aproPegawai.setNamaPegawai(namaPegawai);
        aproPegawai.setBagian(bagian);
        aproPegawai.setAlamatPegawai(alamatPegawai);
        aproPegawai.setNoTelp(noTelp);

        aproDaoPegawai.updatePegawai(aproPegawai);
        fireOnUpdate(aproPegawai);
    }

    public void deletePegawai() throws SQLException, AProException {

        AProDaoPegawai aproDaoPegawai = AProDatabase.getAProDaoPegawai();
        aproDaoPegawai.deletePegawai(idPegawai);
        fireOnDelete();
    }
}
