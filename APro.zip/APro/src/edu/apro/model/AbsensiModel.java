/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.model;

import edu.apro.database.AProDatabase;
import edu.apro.entity.AProAbsensi;
import edu.apro.entity.AProPegawai;
import edu.apro.error.AProException;
import edu.apro.event.AbsensiListener;
import edu.apro.service.AProDaoAbsensi;
import edu.apro.service.AProDaoPegawai;
import java.sql.SQLException;

/**
 *
 * @author Tsukandar
 */
public class AbsensiModel {

    private String noAbsen;
    private String idPegawai;
    private String bagian;
    private String upah;
    private String jumlahKehadiran;

    private AbsensiListener absensiListener;

    public AbsensiListener getAbsensiListener() {
        return absensiListener;
    }

    public void setAbsensiListener(AbsensiListener absensiListener) {
        this.absensiListener = absensiListener;
    }

    public String getNoAbsen() {
        return noAbsen;
    }

    public void setNoAbsen(String noAbsen) {
        this.noAbsen = noAbsen;
    }

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getBagian() {
        return bagian;
    }

    public void setBagian(String bagian) {
        this.bagian = bagian;
    }

    public String getUpah() {
        return upah;
    }

    public void setUpah(String upah) {
        this.upah = upah;
    }

    public String getJumlahKehadiran() {
        return jumlahKehadiran;
    }

    public void setJumlahKehadiran(String jumlahKehadiran) {
        this.jumlahKehadiran = jumlahKehadiran;
    }

    protected void fireOnChange() {
        if (absensiListener != null) {
            absensiListener.onChange(this);
        }
    }

    protected void fireOnInsert(AProAbsensi aproAbsensi) {
        if (absensiListener != null) {
            absensiListener.onInsert(aproAbsensi);
        }
    }

    protected void fireOnUpdate(AProAbsensi aproAbsensi) {
        if (absensiListener != null) {
            absensiListener.onUpdate(aproAbsensi);
        }
    }

    protected void fireOnDelete() {
        if (absensiListener != null) {
            absensiListener.onDelete();
        }
    }

    public void insertAbsensi() throws SQLException, AProException {

        AProDaoAbsensi aproDaoAbsensi = AProDatabase.getAProDaoAbsensi();
        AProAbsensi aproAbsensi = new AProAbsensi();
        aproAbsensi.setNoAbsen(noAbsen);
        aproAbsensi.setIdPegawai(idPegawai);
        aproAbsensi.setBagian(bagian);
        aproAbsensi.setUpah(upah);
        aproAbsensi.setJumlahKehadiran(jumlahKehadiran);

        aproDaoAbsensi.insertAbsensi(aproAbsensi);
        fireOnInsert(aproAbsensi);
    }

    public void updateAbsensi() throws SQLException, AProException {

        AProDaoAbsensi aproDaoAbsensi = AProDatabase.getAProDaoAbsensi();
        AProAbsensi aproAbsensi = new AProAbsensi();
        aproAbsensi.setNoAbsen(noAbsen);
        aproAbsensi.setIdPegawai(idPegawai);
        aproAbsensi.setBagian(bagian);
        aproAbsensi.setUpah(upah);
        aproAbsensi.setJumlahKehadiran(jumlahKehadiran);

        aproDaoAbsensi.updateAbsensi(aproAbsensi);
        fireOnUpdate(aproAbsensi);
    }

    public void deleteAbsensi() throws SQLException, AProException {

        AProDaoAbsensi aproDaoAbsensi = AProDatabase.getAProDaoAbsensi();
        aproDaoAbsensi.deleteAbsensi(idPegawai);
        fireOnDelete();
    }

}
