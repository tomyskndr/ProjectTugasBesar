/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.model;

import edu.apro.entity.AProPegawai;
import edu.apro.entity.AProProyek;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Tsukandar
 */
public class TabelProyekModel extends AbstractTableModel {
    
     private List<AProProyek> list = new ArrayList<AProProyek>();

    public void setList(List<AProProyek> list) {
        this.list = list;
    }

     
    @Override
    public int getRowCount() {
    return list.size();    
    }

    @Override
    public int getColumnCount() {
    return 3;
    }

    public boolean add(AProProyek e) {
        try {
            return list.add(e);
        } finally  {
            fireTableRowsInserted(getRowCount()-1, getRowCount()-1);
        }
    }

    public AProProyek get(int i) {
        return list.get(i);
    }

    public AProProyek set(int i, AProProyek e) {
        try {
            
        return list.set(i, e);
        } finally {
            fireTableRowsUpdated(i, i);
        }
    }

    public AProProyek remove(int i) {
            try {

            return list.remove(i);
            } finally {
                fireTableRowsDeleted(i, i);
            }
    }

    
    
    @Override
    public String getColumnName(int i) {
        switch (i) {
            case 0:
                return "KODE";
            case 1:
                return "NAMA";
            case 2:
                return "ID";
            default:
                return null;    
            }
    }
    

    @Override
    public Object getValueAt(int i, int i1) {
    switch (i1) {
            case 0:
                return list.get(i).getKodeProyek();
            case 1:
                return list.get(i).getNamaProyek();
            case 2:
                return list.get(i).getIdPegawai();
            default:
                return null;

        }
    }
   
}
