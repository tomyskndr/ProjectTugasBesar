/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.impl;

import edu.apro.entity.AProAbsensi;
import edu.apro.error.AProException;
import edu.apro.model.PegawaiModel;
import java.sql.Connection;
import java.util.List;
import edu.apro.service.AProDaoAbsensi;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Tsukandar
 */
public class AProDaoAbsensiImpl implements AProDaoAbsensi {

    private Connection connection;

    private final String insertAbsensi = "INSERT INTO absensi (No_Absen,Id_Pegawai,Bagian,Upah,Jumlah_Kehadiran) VALUES(?,?,?,?,?)";

    private final String updateAbsensi = "UPDATE absensi SET Bagian=?,Upah=?,Jumlah_Kehadiran=? WHERE No_Absen=?";

    private final String deleteAbsensi = "DELETE FROM absensi WHERE No_Absen=?";

    private final String getByNama = "SELECT * FROM absensi WHERE=?";

    private final String selectAll = "SELECT * FROM absensi";

    public AProDaoAbsensiImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void insertAbsensi(AProAbsensi aproAbsensi) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);

            statement = connection.prepareStatement(insertAbsensi, Statement.RETURN_GENERATED_KEYS);
             statement.setString(1, aproAbsensi.getNoAbsen());
            statement.setString(2, aproAbsensi.getIdPegawai());
            statement.setString(3, aproAbsensi.getBagian());
            statement.setString(4, aproAbsensi.getUpah());
            statement.setString(5, aproAbsensi.getJumlahKehadiran());
            statement.executeUpdate();

            ResultSet result = statement.getGeneratedKeys();
            if (result.next()) {
                aproAbsensi.setIdPegawai(result.getString(1));
            }
            connection.commit();

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                throw new AProException(e.getMessage());
            }

        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void updateAbsensi(AProAbsensi aproAbsensi) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(updateAbsensi);
            
            statement.setString(1, aproAbsensi.getBagian());
            statement.setString(2, aproAbsensi.getUpah());
            statement.setString(3, aproAbsensi.getJumlahKehadiran());
            statement.setString(4, aproAbsensi.getNoAbsen());
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void deleteAbsensi(String noAbsen) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(deleteAbsensi);
            statement.setString(1, noAbsen);
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {

            throw new AProException(e.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public AProAbsensi getAProAbsensi(String namaPegawai) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(getByNama);
            statement.setString(1, namaPegawai);

            ResultSet result = statement.executeQuery();
            AProAbsensi aproAbsensi = null;

            if (result.next()) {
                aproAbsensi = new AProAbsensi();
                aproAbsensi.setNoAbsen(result.getString("No_Absen"));
                aproAbsensi.setIdPegawai(result.getString("Id_Pegawai"));
                aproAbsensi.setBagian(result.getString("Bagian"));
                aproAbsensi.setUpah(result.getString("Upah"));
                aproAbsensi.setJumlahKehadiran(result.getString("Jumlah_Kehadiran"));

            } else {
                throw new AProException("Pekerja dengan nama " + namaPegawai + " tidak ditemukan");
            }
            connection.commit();
            return aproAbsensi;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public List<AProAbsensi> selectAllAProAbsensi() throws AProException {
        Statement statement = null;
        List<AProAbsensi> list = new ArrayList<AProAbsensi>();

        try {
            connection.setAutoCommit(false);
            statement = connection.createStatement();

            ResultSet result = statement.executeQuery(selectAll);
            AProAbsensi aproAbsensi = null;

            while (result.next()) {
                aproAbsensi = new AProAbsensi();
                aproAbsensi.setNoAbsen(result.getString("No_Absen"));
                aproAbsensi.setIdPegawai(result.getString("Id_Pegawai"));
                aproAbsensi.setBagian(result.getString("Bagian"));
                aproAbsensi.setUpah(result.getString("Upah"));
                aproAbsensi.setJumlahKehadiran(result.getString("Jumlah_Kehadiran"));
                list.add(aproAbsensi);
            }
            connection.commit();
            return list;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }

            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (Exception ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

}
