/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.impl;

import edu.apro.entity.AProAbsensi;
import edu.apro.entity.AProProyek;
import edu.apro.error.AProException;
import edu.apro.service.AProDaoProyek;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tsukandar
 */
public class AProDaoProyekImpl implements AProDaoProyek {

    private Connection connection;

    private final String insertProyek = "INSERT INTO proyek (Kode_Proyek,Nama_Proyek,Id_Pegawai) VALUES(?,?,?)";

    private final String updateProyek = "UPDATE proyek SET Nama_Proyek=? WHERE Kode_Proyek=?";

    private final String deleteProyek = "DELETE FROM proyek WHERE Kode_Proyek=?";

    private final String getByNamaProyek = "SELECT * FROM proyek WHERE=?";

    private final String selectAll = "SELECT * FROM proyek";

    public AProDaoProyekImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void insertProyek(AProProyek aproProyek) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);

            statement = connection.prepareStatement(insertProyek);
            statement.setString(1, aproProyek.getKodeProyek());
            statement.setString(2, aproProyek.getNamaProyek());
            statement.setString(3, aproProyek.getIdPegawai());

            statement.executeUpdate();

            connection.commit();

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                throw new AProException(e.getMessage());
            }

        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void updateProyek(AProProyek aproProyek) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(updateProyek);
            statement.setString(1, aproProyek.getNamaProyek());
            statement.setString(2, aproProyek.getKodeProyek());
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public AProProyek getAProProyek(String namaProyek) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(getByNamaProyek);
            statement.setString(1, namaProyek);

            ResultSet result = statement.executeQuery();
            AProProyek aproProyek = null;

            if (result.next()) {
                aproProyek = new AProProyek();
                aproProyek.setKodeProyek(result.getString("Kode Proyek"));
                aproProyek.setNamaProyek(result.getString("Nama Proyek"));
                aproProyek.setIdPegawai(result.getString("Id Pegawai"));

            } else {
                throw new AProException("Pekerja dengan nama " + namaProyek + " tidak ditemukan");
            }
            connection.commit();
            return aproProyek;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public List<AProProyek> selectAllAProProyek() throws AProException {
        Statement statement = null;
        List<AProProyek> list = new ArrayList<AProProyek>();

        try {
            connection.setAutoCommit(false);
            statement = connection.createStatement();

            ResultSet result = statement.executeQuery(selectAll);
            AProProyek aproProyek = null;

            while (result.next()) {
                aproProyek = new AProProyek();
                aproProyek.setKodeProyek(result.getString("Kode Proyek"));
                aproProyek.setNamaProyek(result.getString("Nama Proyek"));
                aproProyek.setIdPegawai(result.getString("Id Pegawai"));
                list.add(aproProyek);
            }
            connection.commit();
            return list;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }

            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (Exception ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void deleteProyek(String aproProyek) throws AProException {
 

    
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(deleteProyek);
            statement.setString(1, deleteProyek);
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {

            throw new AProException(e.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }


}
