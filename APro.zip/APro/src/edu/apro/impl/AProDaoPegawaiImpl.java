/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.impl;

import edu.apro.entity.AProAbsensi;
import edu.apro.entity.AProPegawai;
import edu.apro.error.AProException;
import edu.apro.service.AProDaoPegawai;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Tsukandar
 */
public class AProDaoPegawaiImpl implements AProDaoPegawai {

    private Connection connection;

    private final String insertPegawai = "INSERT INTO pegawai (Id_Pegawai,Nama_Pegawai,Bagian,Alamat_Pegawai,No_Telp) VALUES(?,?,?,?,?)";

    private final String updatePegawai = "UPDATE pegawai SET Nama_Pegawai=?,Bagian=?,Alamat_Pegawai=?,No_Telp=? WHERE Id_Pegawai=?";

    private final String deletePegawai = "DELETE FROM pegawai WHERE Id_Pegawai=?";

    private final String getByNama = "SELECT * FROM pegawai WHERE=?";

    private final String selectAll = "SELECT * FROM pegawai";

    public AProDaoPegawaiImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void insertPegawai(AProPegawai aproPegawai) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);

            statement = connection.prepareStatement(insertPegawai, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, aproPegawai.getIdPegawai());
            statement.setString(2, aproPegawai.getNamaPegawai());
            statement.setString(3, aproPegawai.getBagian());
            statement.setString(4, aproPegawai.getAlamatPegawai());
            statement.setString(5, aproPegawai.getNoTelp());

            statement.executeUpdate();

            ResultSet result = statement.getGeneratedKeys();
            if (result.next()) {
                aproPegawai.setIdPegawai(result.getString(1));
            }
            connection.commit();

        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
                throw new AProException(e.getMessage());
            }

        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void updatePegawai(AProPegawai aproPegawai) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(updatePegawai);
            statement.setString(1, aproPegawai.getNamaPegawai());
            statement.setString(2, aproPegawai.getBagian());
            statement.setString(3, aproPegawai.getAlamatPegawai());
            statement.setString(4, aproPegawai.getNoTelp());
            statement.setString(5, aproPegawai.getIdPegawai());
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    
    

    @Override
    public AProPegawai getAProPegawai(String namaPegawai) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(getByNama);
            statement.setString(1, namaPegawai);

            ResultSet result = statement.executeQuery();
            AProPegawai aproPegawai = null;

            if (result.next()) {
                aproPegawai = new AProPegawai();
                aproPegawai.setIdPegawai(result.getString("Id_Pegawai"));
                aproPegawai.setNamaPegawai(result.getString("Nama_Pegawai"));
                aproPegawai.setBagian(result.getString("Bagian"));
                aproPegawai.setAlamatPegawai(result.getString("Alamat_Pegawai"));
                aproPegawai.setNoTelp(result.getString("No_Telp"));

            } else {
                throw new AProException("Pekerja dengan nama " + namaPegawai + " tidak ditemukan");
            }
            connection.commit();
            return aproPegawai;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }
            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (SQLException ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public List<AProPegawai> selectAllAProPegawai() throws AProException {
        Statement statement = null;
        List<AProPegawai> list = new ArrayList<AProPegawai>();

        try {
            connection.setAutoCommit(false);
            statement = connection.createStatement();

            ResultSet result = statement.executeQuery(selectAll);
            AProPegawai aproPegawai = null;

            while (result.next()) {
                aproPegawai = new AProPegawai();
               aproPegawai.setIdPegawai(result.getString("Id_Pegawai"));
                aproPegawai.setNamaPegawai(result.getString("Nama_Pegawai"));
                aproPegawai.setBagian(result.getString("Bagian"));
                aproPegawai.setAlamatPegawai(result.getString("Alamat_Pegawai"));
                aproPegawai.setNoTelp(result.getString("No_Telp"));
                list.add(aproPegawai);
            }
            connection.commit();
            return list;
        } catch (SQLException e) {

            try {
                connection.rollback();
            } catch (SQLException ex) {
            }

            throw new AProException(e.getMessage());
        } finally {
            try {
                connection.setAutoCommit(true);
            } catch (Exception ex) {
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }

    @Override
    public void deletePegawai(String idPegawai) throws AProException {
        PreparedStatement statement = null;
        try {
            connection.setAutoCommit(false);
            statement = connection.prepareStatement(deletePegawai);
            statement.setString(1, idPegawai);
            statement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {

            throw new AProException(e.getMessage());
        } finally {
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                }
            }

        }
    }
    

}
