/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.event;

import edu.apro.entity.AProAbsensi;
import edu.apro.model.AbsensiModel;

/**
 *
 * @author Tsukandar
 */
public interface AbsensiListener {
    public void onChange(AbsensiModel absensiModel);

    public void onInsert(AProAbsensi aproAbsensi);

    public void onDelete();

    public void onUpdate(AProAbsensi aproAbsensi);
}
