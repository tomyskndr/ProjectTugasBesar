/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.event;

import edu.apro.entity.AProPegawai;
import edu.apro.model.PegawaiModel;

/**
 *
 * @author Tsukandar
 */
public interface PegawaiListener {

    public void onChange(PegawaiModel pegawaiModel);

    public void onInsert(AProPegawai aproPegawai);

    public void onDelete();

    public void onUpdate(AProPegawai aproPegawai);
}
