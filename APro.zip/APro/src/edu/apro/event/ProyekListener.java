/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.event;

import edu.apro.entity.AProProyek;
import edu.apro.model.ProyekModel;

/**
 *
 * @author Tsukandar
 */
public interface ProyekListener {
    
    public void onChange(ProyekModel proyekModel);

    public void onInsert(AProProyek aproProyek);

    public void onDelete();

    public void onUpdate(AProProyek aproProyek);
}
