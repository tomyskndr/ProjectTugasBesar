/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.entity;

import java.util.Objects;

/**
 *
 * @author Tsukandar
 */
public class AProAbsensi {
    
    private String noAbsen;
    private String idPegawai;
    private String bagian;
    private String upah;
    private String jumlahKehadiran;
    
    public AProAbsensi(){
        
    }

    public AProAbsensi(String noAbsen, String idPegawai, String bagian, String upah, String jumlahKehadiran) {
        this.noAbsen = noAbsen;
        this.idPegawai = idPegawai;
        this.bagian = bagian;
        this.upah = upah;
        this.jumlahKehadiran = jumlahKehadiran;
    }
    

    public String getNoAbsen() {
        return noAbsen;
    }

    public void setNoAbsen(String noAbsen) {
        this.noAbsen = noAbsen;
    }

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getBagian() {
        return bagian;
    }

    public void setBagian(String bagian) {
        this.bagian = bagian;
    }

    public String getUpah() {
        return upah;
    }

    public void setUpah(String upah) {
        this.upah = upah;
    }

    public String getJumlahKehadiran() {
        return jumlahKehadiran;
    }

    public void setJumlahKehadiran(String jumlahKehadiran) {
        this.jumlahKehadiran = jumlahKehadiran;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.noAbsen);
        hash = 29 * hash + Objects.hashCode(this.idPegawai);
        hash = 29 * hash + Objects.hashCode(this.bagian);
        hash = 29 * hash + Objects.hashCode(this.upah);
        hash = 29 * hash + Objects.hashCode(this.jumlahKehadiran);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AProAbsensi other = (AProAbsensi) obj;
        if (!Objects.equals(this.noAbsen, other.noAbsen)) {
            return false;
        }
        if (!Objects.equals(this.idPegawai, other.idPegawai)) {
            return false;
        }
        if (!Objects.equals(this.bagian, other.bagian)) {
            return false;
        }
        if (!Objects.equals(this.upah, other.upah)) {
            return false;
        }
        if (!Objects.equals(this.jumlahKehadiran, other.jumlahKehadiran)) {
            return false;
        }
        return true;
    }
    
    
    
}
