/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.apro.entity;

import java.util.Objects;

/**
 *
 * @author Tsukandar
 */
public class AProProyek {
    
    private String kodeProyek;
    private String namaProyek;
    private String idPegawai;
    
    public AProProyek(){
        
    }

    public AProProyek(String kodeProyek, String namaProyek, String idPegawai) {
        this.kodeProyek = kodeProyek;
        this.namaProyek = namaProyek;
        this.idPegawai = idPegawai;
    }
    

    public String getKodeProyek() {
        return kodeProyek;
    }

    public void setKodeProyek(String kodeProyek) {
        this.kodeProyek = kodeProyek;
    }

    public String getNamaProyek() {
        return namaProyek;
    }

    public void setNamaProyek(String namaProyek) {
        this.namaProyek = namaProyek;
    }

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.kodeProyek);
        hash = 53 * hash + Objects.hashCode(this.namaProyek);
        hash = 53 * hash + Objects.hashCode(this.idPegawai);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AProProyek other = (AProProyek) obj;
        if (!Objects.equals(this.kodeProyek, other.kodeProyek)) {
            return false;
        }
        if (!Objects.equals(this.namaProyek, other.namaProyek)) {
            return false;
        }
        if (!Objects.equals(this.idPegawai, other.idPegawai)) {
            return false;
        }
        return true;
    }
    
    
    
}
