package edu.apro.entity;


import java.util.Objects;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tsukandar
 */
public class AProPegawai {
    
    private String idPegawai;
    private String namaPegawai;
    private String bagian;
    private String alamatPegawai;
    private String noTelp;
    
    public AProPegawai(){
        
    }

    public AProPegawai(String idPegawai, String namaPegawai, String bagian, String alamatPegawai, String noTelp) {
        this.idPegawai = idPegawai;
        this.namaPegawai = namaPegawai;
        this.bagian = bagian;
        this.alamatPegawai = alamatPegawai;
        this.noTelp = noTelp;
    }
    

    public String getIdPegawai() {
        return idPegawai;
    }

    public void setIdPegawai(String idPegawai) {
        this.idPegawai = idPegawai;
    }

    public String getNamaPegawai() {
        return namaPegawai;
    }

    public void setNamaPegawai(String namaPegawai) {
        this.namaPegawai = namaPegawai;
    }

    public String getBagian() {
        return bagian;
    }

    public void setBagian(String bagian) {
        this.bagian = bagian;
    }

    public String getAlamatPegawai() {
        return alamatPegawai;
    }

    public void setAlamatPegawai(String alamatPegawai) {
        this.alamatPegawai = alamatPegawai;
    }

    public String getNoTelp() {
        return noTelp;
    }

    public void setNoTelp(String noTelp) {
        this.noTelp = noTelp;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 61 * hash + Objects.hashCode(this.idPegawai);
        hash = 61 * hash + Objects.hashCode(this.namaPegawai);
        hash = 61 * hash + Objects.hashCode(this.bagian);
        hash = 61 * hash + Objects.hashCode(this.alamatPegawai);
        hash = 61 * hash + Objects.hashCode(this.noTelp);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AProPegawai other = (AProPegawai) obj;
        if (!Objects.equals(this.idPegawai, other.idPegawai)) {
            return false;
        }
        if (!Objects.equals(this.namaPegawai, other.namaPegawai)) {
            return false;
        }
        if (!Objects.equals(this.bagian, other.bagian)) {
            return false;
        }
        if (!Objects.equals(this.alamatPegawai, other.alamatPegawai)) {
            return false;
        }
        if (!Objects.equals(this.noTelp, other.noTelp)) {
            return false;
        }
        return true;
    }
    
    
    
}
